---
type: Note
okf_version: "0.1"
title: Willkommen im Marketing-Workspace
processed: false
timestamp: 2026-07-01T00:00:00Z
---

# Willkommen!

Das ist dein RAW-Ordner — hier schreibst du alles rein.

## Wie du ihn nutzt

- **Notizen** aus Kundengesprächen → einfach reinschreiben
- **Ideen** für Content → rein damit
- **Dokumente** → als .md oder .txt ablegen
- **Pitch-Deck-Inhalte** → copy/paste rein

Der Agent liest alles hier drin, erstellt strukturierte Artikel in `wiki/` und hält `.agents/product-marketing.md` aktuell — dein Marketing-Brain wächst mit jedem Update.

## Als nächstes

Starte mit `/grill-me-workshop` — das Interview dauert ca. 15 Minuten
und aktiviert danach alle 44 Marketing-Skills.
