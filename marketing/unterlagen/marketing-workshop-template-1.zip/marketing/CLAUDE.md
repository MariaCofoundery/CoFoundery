# Marketing-Workspace

Lies beim Start dieses Projekts zuerst `.agents/product-marketing.md` — das ist
die vollständige Wissensbasis über dieses Startup. Falls die Datei noch nicht
existiert, weise darauf hin dass `/grill-me-workshop` als erster Schritt
ausgeführt werden sollte.

## Wie dieser Ordner funktioniert

**Du schreibst nur in `RAW/`** — alles andere wird vom Agenten verwaltet.

### Datenfluss

```
RAW/          ← du schreibst hier (Notizen, Gespräche, Ideen)
    ↓
wiki/         ← das Marketing-Brain (OKF-Artikel, wächst mit jedem Update)
    ↓
.agents/product-marketing.md  ← Ableitung für alle 44 Skills
    ↓
44 Marketing-Skills  ← lesen .agents/ automatisch
```

`wiki/` ist der zentrale Wissensspeicher dieses Projekts. Alles was ihr über
euer Startup, euer Angebot, eure Kunden und eure Positionierung wisst,
landet strukturiert dort — und wächst mit der Zeit.

### Die drei Skills die du kennst

| Wann | Skill | Was passiert |
|------|-------|-------------|
| Einmalig zu Beginn | `/grill-me-workshop` | Interview → füllt wiki/ + .agents/ |
| Nach neuen Infos | `/update-context` | RAW-Dateien → aktualisiert wiki/ + .agents/ |
| Für Marketing-Aufgaben | `/copywriting`, `/seo-audit`, etc. | Lesen .agents/ automatisch |

### Neue Infos hinzufügen

Einfach eine neue Datei in `RAW/` legen — Stichpunkte, Gesprächsnotizen,
Ideen, copy/paste aus E-Mails. Dann `/update-context` aufrufen.
Claude verarbeitet das, erweitert wiki/, und hält alle Skills auf dem neuesten Stand.

### Wichtige Regeln

- RAW-Dateien werden **niemals gelöscht**, nur als `processed: true` markiert
- `wiki/`, `.agents/` **nicht manuell bearbeiten**
- Korrekturen immer über `RAW/` einbringen — wiki/ wird dann daraus aktualisiert
