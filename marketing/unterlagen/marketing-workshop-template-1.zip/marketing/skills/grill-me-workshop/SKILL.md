---
name: grill-me-workshop
version: v1.2
scope: ws-dh-omww
autor: cf
erstellt: 2026-07-01
aktualisiert: 2026-07-01
status: aktiv
triggers:
  - "grill me workshop"
  - "kontext aufbauen"
  - "startup context"
  - "setup marketing kontext"
  - "onboarding"
beschreibung: >
  Einmaliges Kontext-Interview für Workshop-Startups.
  Schreibt die Basis-Wiki-Artikel in wiki/ (das Marketing-Brain)
  und leitet daraus .agents/product-marketing.md ab.
  Nach diesem Skill sind alle 44 Marketing-Skills sofort einsatzbereit.
---

# /grill-me-workshop — Startup-Kontext-Interview

## Was dieser Skill tut

Führt ein einziges strukturiertes Interview durch und schreibt:

1. **`wiki/startup.md`** — Wer ihr seid (OKF, Wiki-Artikel)
2. **`wiki/angebot.md`** — Was ihr verkauft (OKF, Wiki-Artikel)
3. **`wiki/zielgruppe.md`** — Wen ihr ansprecht (OKF, Wiki-Artikel)
4. **`wiki/positionierung.md`** — Wie ihr euch positioniert (OKF, Wiki-Artikel)
5. **`.agents/product-marketing.md`** — Komprimierte Zusammenfassung für alle 44 Skills (automatisch abgeleitet aus wiki/)

`wiki/` ist das Brain dieses Projekts. Es wächst mit jedem `/update-context`-Aufruf.
`.agents/product-marketing.md` ist immer eine Ableitung daraus — nie eigenständig.

---

## Schritt 1: Vorbereitung

Prüfe ob bereits Informationen vorliegen:

- `RAW/` — Dateien mit `processed: false` oder ohne processed-Flag → lesen
- `wiki/` — schon befüllt? → einlesen, nur Lücken fragen
- `.agents/product-marketing.md` — schon vorhanden? → einlesen als Kontext

Wenn RAW-Dateien existieren: Lese sie, erstelle einen Vorab-Entwurf, zeige ihn,
frage nur nach was fehlt oder unklar ist.

---

## Schritt 2: Interview

Block für Block, nicht als Fragenliste. Kurze Erklärung warum du den Block brauchst.
Bei vagen Antworten nachbohren.

### Block A — Das Startup
- Wie heißt ihr, und was macht ihr in einem Satz — für wen, mit welchem Ergebnis?
- Seit wann? Phase: Idee / MVP / erste Umsätze / Wachstum?
- Wer ist im Team (Rollen)?

### Block B — Eure digitale Basis
- Website-URL? (Falls keine: wann geplant oder gar nicht?)
- Logo vorhanden? → Ja / Nein / In Arbeit
- Welche Social-Media-Kanäle aktiv? (Plattform + Handle)
- E-Mail-Liste? → Nein / Ja — ca. wie viele Kontakte?
- Website-Besucher pro Monat ungefähr?

### Block C — Das Angebot
- Konkreter Produktname / Angebotsname?
- Was bekommt jemand der kauft — 2–3 Sätze?
- Auf welchem "Regal" suchen Kunden nach euch? (Wie googeln sie das?)
- Preismodell und konkreter Preis?
- Der EINE Grund warum jemand bei euch kauft und nicht woanders?

### Block D — Zielgruppe & Personas
- B2B oder B2C?
- Idealer Kunde: Branche / Größe / Rolle (B2B) oder Alter / Situation / Typ (B2C)?
- Wo sind eure Kunden online aktiv?
- Nur B2B: Wer kauft, wer entscheidet, wer zahlt?
- Wer ist ausdrücklich KEIN guter Kunde? (Anti-Persona)

### Block E — Das Problem & Switching
- Größtes Problem eurer Kunden bevor sie euch finden?
- Was kostet sie das — Zeit, Geld, verpasste Chancen?
- Was haben sie vorher versucht? Warum hat es nicht gereicht?
- Was hält sie bei der alten Lösung?
- Wie beschreiben sie das Problem in ihren eigenen Worten? (Verbatim)

### Block F — Positionierung & Wettbewerb
- Direkte Wettbewerber (gleiche Lösung)?
- Indirekte Alternativen (andere Ansätze)?
- Warum fallen diese für eure Kunden kurz?
- Was macht euch konkret anders?

### Block G — Einwände & Kundensprache
- Top-3 Einwände die ihr hört + eure Antworten?
- Was sagen zufriedene Kunden über euch — verbatim?
- Wörter die ihr benutzt? Wörter die ihr vermeidet?

### Block H — Brand Voice
- 3 Adjektive die euren Ton beschreiben?
- Was sagt ihr NIE?
- Ein Beispielsatz der nach euch klingt?

### Block I — Beweise & Zahlen
- Ergebnisse / Zahlen die ihr nennen könnt?
- Bekannte Kunden oder Referenzen?
- Ein konkretes Kundenzitat?

### Block J — Fokus & Ziele
- Wichtigstes Marketing-Ziel gerade?
- Was soll jemand tun der eure Website sieht? (CTA)
- Was messt ihr bereits?
- Euer EINE Haupthebel aus dem Workshop-Deep-Dive?
- Die EINE konkrete Aufgabe diese Woche?

---

## Schritt 3: Entwurf bestätigen

```
STARTUP:     [Name] — [One-Liner]
URL:         [Website]
ANGEBOT:     [Produktname, Preismodell, Preis]
ZIELGRUPPE:  [ICP-Profil]
PROBLEM:     [Kernproblem]
POSITION:    [Differenzierung]
STIMME:      [3 Adjektive]
FOKUS:       [Haupthebel + eine Aufgabe]
```

"Passt das? Was ist falsch oder fehlt?"

---

## Schritt 4: wiki/ schreiben

Erstelle `wiki/` falls nicht vorhanden.

### `wiki/startup.md`
```markdown
---
type: Wiki Article
okf_version: "0.1"
title: [Name] — Startup
description: "[One-Liner]"
scope: [projektname]
slug: startup
tags: [startup, kontext]
timestamp: [ISO-8601]
processed: true
---

# [Name]

**One-Liner:** [...]
**Phase:** [...]
**Website:** [URL]
**Logo:** [Ja / Nein / In Arbeit]
**Social Media:**
- [Plattform]: [Handle]
**E-Mail-Liste:** [Nein / Ja — N Kontakte]
**Besucher/Monat:** [ca. N]
**Team:** [Rollen]
```

### `wiki/angebot.md`
```markdown
---
type: Wiki Article
okf_version: "0.1"
title: [Name] — Angebot
description: "[Produktname in einem Satz]"
slug: angebot
tags: [angebot, produkt, preis]
timestamp: [ISO-8601]
processed: true
---

# Angebot: [Produktname]

**Kernleistung:** [Was genau]
**Kategorie / Regal:** [Wie Kunden danach suchen]
**Preismodell:** [Modell]
**Preis:** [Konkret]
**Hauptnutzen:** [Der eine Grund zu kaufen]
**Differenzierung:** [Was uns konkret anders macht]
```

### `wiki/zielgruppe.md`
```markdown
---
type: Wiki Article
okf_version: "0.1"
title: [Name] — Zielgruppe
description: "[ICP in einem Satz]"
slug: zielgruppe
tags: [zielgruppe, icp, persona]
timestamp: [ISO-8601]
processed: true
---

# Zielgruppe

**ICP:** [Profil]
**Online:** [Plattformen, Communities]
**Hauptproblem:** [Kernfrustration]
**Was es kostet:** [Zeit, Geld, Chancen]
**Was sie vorher versucht haben:** [Alternativen + Warum gescheitert]
**Switching:** Push / Pull / Habit / Anxiety
**Anti-Persona:** [Wer nicht passt]

## Personas (B2B)
| Rolle | Interesse | Herausforderung | Unser Versprechen |
|-------|-----------|-----------------|-------------------|
| Nutzer | | | |
| Entscheider | | | |
| Zahler | | | |

## Ihre eigene Sprache
> "[Verbatim-Zitat 1]"
> "[Verbatim-Zitat 2]"

**Wörter die sie benutzen:** [Liste]
**Wörter die wir vermeiden:** [Liste]
```

### `wiki/positionierung.md`
```markdown
---
type: Wiki Article
okf_version: "0.1"
title: [Name] — Positionierung
description: "[Kernpositionierung]"
slug: positionierung
tags: [positionierung, wettbewerb, differenzierung]
timestamp: [ISO-8601]
processed: true
---

# Positionierung

**Kernbotschaft:** [Was uns unique macht]

## Wettbewerb
| Art | Wettbewerber | Fällt kurz weil |
|-----|-------------|-----------------|
| Direkt | | |
| Indirekt | | |

**Warum Kunden uns wählen:** [...]

## Differenzierung
- [Punkt 1]
- [Punkt 2]

## Einwände
| Einwand | Antwort |
|---------|---------|
| | |

## Brand Voice
**Ton:** [3 Adjektive]
**Nie:** [Tabus]
**Beispielsatz:** "[...]"

## Beweise
**Zahlen:** [...]
**Kundenzitat:** > "[...]"

## Fokus
**Haupthebel:** [...]
**Diese Woche:** [Eine Aufgabe]
**Ziel:** [Marketing-Ziel]
**CTA:** [Was Besucher tun sollen]
**Metriken:** [Was gemessen wird]
```

---

## Schritt 5: .agents/product-marketing.md ableiten

Lege `.agents/` an falls nötig: `mkdir -p .agents`

Lies alle `wiki/*.md` Dateien zusammen und schreibe eine komprimierte
`.agents/product-marketing.md` im Corey-Haines-Format daraus ab.
Diese Datei wird nie manuell bearbeitet — sie ist immer eine Ableitung aus wiki/.

Format: siehe product-marketing Skill im skills/marketingskills/ Ordner.

---

## Schritt 6: RAW-Dateien markieren

Alle gelesenen RAW-Dateien: `processed: true` + `processed_at: [ISO-8601]` setzen.

---

## Schritt 7: Abschluss

```
✓ wiki/startup.md
✓ wiki/angebot.md
✓ wiki/zielgruppe.md
✓ wiki/positionierung.md
✓ .agents/product-marketing.md (abgeleitet aus wiki/)

Das Marketing-Brain ist aufgebaut.
Alle 44 Skills sind einsatzbereit.

Nächstes Mal wenn ihr neue Infos habt: einfach in RAW/ ablegen
und /update-context aufrufen.
```

---

## Regeln

- Wiki/ ist die einzige Quelle — nie direkt in .agents/ schreiben
- .agents/product-marketing.md immer vollständig aus wiki/ ableiten
- RAW-Dateien nie löschen, nur als processed markieren
- Verbatim-Zitate priorisieren
