---
name: update-context
version: v1.1
scope: ws-dh-omww
autor: cf
erstellt: 2026-07-01
aktualisiert: 2026-07-01
status: aktiv
triggers:
  - "update context"
  - "kontext aktualisieren"
  - "neue infos"
  - "kundengespräch verarbeiten"
  - "raw verarbeiten"
  - "wiki aktualisieren"
beschreibung: >
  Liest neue RAW-Dateien, aktualisiert wiki/*.md (OKF, das Marketing-Brain) und leitet daraus
  .agents/product-marketing.md neu ab. Hält alle 44 Skills automatisch aktuell.
---

# /update-context — Wiki & Kontext aktualisieren

## Was dieser Skill tut

Wenn sich etwas ändert — neues Kundengespräch, neuer Preis, neue Erkenntnis —
legt ihr die Info einfach in `RAW/`. Dieser Skill:

1. Liest alle RAW-Dateien die noch nicht verarbeitet sind (`processed: false` oder kein Flag)
2. Liest die bestehenden `wiki/*.md` Dateien (das Marketing-Brain)
3. Ergänzt oder korrigiert die Wiki-Artikel mit den neuen Infos
4. Leitet `.agents/product-marketing.md` neu aus `wiki/` ab
5. Markiert verarbeitete RAW-Dateien als `processed: true`

**Datenfluss:** RAW/ → wiki/ → .agents/ → 44 Skills

**RAW-Dateien werden niemals gelöscht** — nur als verarbeitet markiert.

---

## Ablauf

### Schritt 1: Neue RAW-Dateien finden

Lese alle Dateien in `RAW/` die entweder:
- `processed: false` im Frontmatter haben
- kein `processed:`-Feld haben (= noch nie verarbeitet)

Überspringe Dateien mit `processed: true`.

Falls keine neuen RAW-Dateien gefunden: sag das kurz und beende den Skill.

### Schritt 2: Bestehendes Wiki lesen

Lese alle bestehenden `wiki/*.md` Dateien und `.agents/product-marketing.md`.
Das ist die aktuelle Wissensbasis.

Falls `wiki/` noch leer oder nicht vorhanden: schlage vor, zuerst `/grill-me-workshop`
auszuführen um die Basis-Wiki-Artikel zu erstellen.

### Schritt 3: Neue Infos einarbeiten

Für jede neue RAW-Datei: Was ist neu, was widerspricht dem bestehenden Wiki,
was ergänzt es?

Kategorisiere die Information:
- Neue Info über das **Startup** → `wiki/startup.md`
- Neue Info über das **Angebot** (Preis, Feature, Name) → `wiki/angebot.md`
- Neue Info über **Kunden** (Zitate, Personas, Einwände) → `wiki/zielgruppe.md`
- Neue Info über **Positionierung** (Differenzierung, Wettbewerb) → `wiki/positionierung.md`
- Neues Thema das keines der Basis-Artikel trifft → neuen Wiki-Artikel anlegen (z.B. `wiki/kampagne-launch.md`)
- Mehrere Kategorien → mehrere Artikel aktualisieren

Zeige dem Nutzer kurz was du gefunden hast:
```
NEU in RAW/kundengespräch-2026-07-01.md:
→ Neues Verbatim-Zitat: "wir haben früher 3 Stunden pro Woche verloren..."
→ Neuer Einwand: "zu teuer für uns als Startup"
→ Zielgruppe konkreter: CFOs in Series-A-Startups

Wird eingearbeitet in: wiki/zielgruppe.md, wiki/positionierung.md
```

Frage: "Passt das? Oder gibt es was das ich falsch interpretiert habe?"

### Schritt 4: wiki/*.md aktualisieren

Aktualisiere die relevanten Wiki-Artikel. OKF-Format beibehalten.
Neue Infos ergänzen, veraltete Infos korrigieren oder streichen.
`timestamp` im Frontmatter aktualisieren.

Wenn ein Wiki-Artikel noch nicht existiert: neu anlegen mit OKF-Frontmatter.

### Schritt 5: .agents/product-marketing.md neu ableiten

Lese alle `wiki/*.md` Dateien zusammen und schreibe `.agents/product-marketing.md`
vollständig neu — aus dem aktuellen Stand von `wiki/`, nicht aus dem alten Stand
der Datei selbst.

Das stellt sicher dass `.agents/product-marketing.md` immer eine saubere Ableitung
aus `wiki/` ist — nie ein akkumulierter Flickenteppich.

### Schritt 6: RAW-Dateien als verarbeitet markieren

Für jede verarbeitete RAW-Datei: `processed: true` und `processed_at: [ISO-8601]`
ins Frontmatter schreiben.

Falls kein Frontmatter vorhanden: am Anfang der Datei ergänzen.

### Schritt 7: Abschluss

```
✓ [N] RAW-Datei(en) verarbeitet
✓ wiki/[dateien] aktualisiert
✓ .agents/product-marketing.md neu abgeleitet aus wiki/

Alle 44 Marketing-Skills kennen jetzt den neuen Stand.
```

---

## Regeln

- RAW-Dateien niemals löschen oder inhaltlich verändern — nur `processed: true` setzen
- `.agents/product-marketing.md` immer vollständig aus wiki/ ableiten, nie manuell bearbeiten
- wiki/ ist das Brain — nie direkt .agents/ schreiben ohne wiki/ Basis
- Bei Widersprüchen zwischen RAW und wiki/: nachfragen statt raten
- Wenn eine RAW-Datei unklar ist: kurz nachfragen bevor einarbeiten
