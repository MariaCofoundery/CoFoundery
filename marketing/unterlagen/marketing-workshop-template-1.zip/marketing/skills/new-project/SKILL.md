---
name: new-project
version: v1.1
scope: ws-dh-omww
autor: cf
erstellt: 2026-07-01
aktualisiert: 2026-07-01
status: aktiv
triggers:
  - "new project"
  - "neues projekt"
  - "projekt anlegen"
  - "marketing ordner"
  - "setup marketing"
beschreibung: >
  Legt die vollständige Marketing-Projektstruktur an.
  Erstellt alle Ordner, CLAUDE.md, _bundle.yml und kopiert alle Skills.
  Danach: /grill-me-workshop starten.
---

# /new-project — Marketing-Projektstruktur anlegen

## Was dieser Skill tut

Legt in Sekunden eine vollständige, KI-ready Marketing-Struktur an:

```
marketing/
├── CLAUDE.md              ← Steuerungsdatei für den Agenten
├── _bundle.yml            ← OKF Bundle-Konfiguration
├── RAW/                   ← Hier schreibt ihr (Notizen, Dokumente)
│   └── .gitkeep
├── wiki/                  ← das Marketing-Brain (OKF-Artikel, wächst)
│   └── .gitkeep
├── .agents/               ← Ableitung für alle 44 Skills (nie manuell bearbeiten)
│   └── .gitkeep
└── skills/                ← 44+ Marketing-Skills, sofort einsatzbereit
    ├── grill-me-workshop/SKILL.md
    ├── update-context/SKILL.md
    └── marketingskills/
        └── [44 Skills von Corey Haines]
```

**Datenfluss:** RAW/ → wiki/ → .agents/product-marketing.md → 44 Skills

---

## Ablauf

### Schritt 1: Projektname klären

Frage: "Wie heißt euer Startup / euer Projekt?"

Leite daraus den Scope-Namen ab (lowercase, Bindestriche statt Leerzeichen).
Beispiel: "ToysReloved" → Scope `toysreloved`, Root-Ordner immer `marketing/`

Wenn bereits ein `marketing/`-Ordner existiert:
→ Prüfe was schon drin ist
→ Füge nur Fehlendes hinzu, überschreibe nichts

### Schritt 2: Ordnerstruktur anlegen

```bash
mkdir -p marketing/RAW
mkdir -p marketing/wiki
mkdir -p marketing/.agents
mkdir -p marketing/skills/marketingskills
touch marketing/RAW/.gitkeep
touch marketing/wiki/.gitkeep
touch marketing/.agents/.gitkeep
```

### Schritt 3: CLAUDE.md schreiben

Erstelle `marketing/CLAUDE.md` mit dem Projektnamen des Startups:

```markdown
# [Projektname] — Marketing-Workspace

Lies beim Start dieses Projekts zuerst `.agents/product-marketing.md` — das ist
die vollständige Wissensbasis über dieses Startup. Falls die Datei noch nicht
existiert, weise darauf hin dass `/grill-me-workshop` als erster Schritt
ausgeführt werden sollte.

## Wie dieser Ordner funktioniert

**Du schreibst nur in `RAW/`** — alles andere wird vom Agenten verwaltet.

### Datenfluss

```
RAW/          ← du schreibst hier (Notizen, Gespräche, Ideen)
    ↓
wiki/         ← das Marketing-Brain (OKF-Artikel, wächst mit jedem Update)
    ↓
.agents/product-marketing.md  ← Ableitung für alle 44 Skills
    ↓
44 Marketing-Skills  ← lesen .agents/ automatisch
```

`wiki/` ist der zentrale Wissensspeicher dieses Projekts. Alles was ihr über
euer Startup, euer Angebot, eure Kunden und eure Positionierung wisst,
landet strukturiert dort — und wächst mit der Zeit.

### Die drei Skills die du kennst

| Wann | Skill | Was passiert |
|------|-------|-------------|
| Einmalig zu Beginn | `/grill-me-workshop` | Interview → füllt wiki/ + .agents/ |
| Nach neuen Infos | `/update-context` | RAW-Dateien → aktualisiert wiki/ + .agents/ |
| Für Marketing-Aufgaben | `/copywriting`, `/seo-audit`, etc. | Lesen .agents/ automatisch |

### Wichtige Regeln

- RAW-Dateien werden **niemals gelöscht**, nur als `processed: true` markiert
- `wiki/`, `.agents/` **nicht manuell bearbeiten**
- Korrekturen immer über `RAW/` einbringen — wiki/ wird dann daraus aktualisiert
```

### Schritt 4: _bundle.yml schreiben

Erstelle `marketing/_bundle.yml`:

```yaml
# OKF Bundle-Konfiguration — Marketing-Workspace
okf_version: "0.1"
bundle_type: marketing-workspace
scope: "[projektname-lowercase]"

ingestion:
  enabled: true
  watch: RAW/
  output: wiki/
  strategy: okf

skills:
  path: skills/
  active:
    - grill-me-workshop
    - update-context
    - marketingskills/*

created: [ISO-8601 heute]
```

### Schritt 5: Skills kopieren

Kopiere `grill-me-workshop/SKILL.md` und `update-context/SKILL.md` in `marketing/skills/`:

```bash
mkdir -p marketing/skills/grill-me-workshop marketing/skills/update-context
cp [pfad-zu-skills]/grill-me-workshop/SKILL.md marketing/skills/grill-me-workshop/SKILL.md
cp [pfad-zu-skills]/update-context/SKILL.md marketing/skills/update-context/SKILL.md
```

Kopiere alle Corey-Haines-Skills (Ordner-pro-Skill, je `SKILL.md`) in `marketing/skills/marketingskills/`:

```bash
mkdir -p marketing/skills/marketingskills
cp -r [pfad-zu-skills]/marketingskills/*/ marketing/skills/marketingskills/
```

> Hinweis: Wenn dieses Template als ZIP entpackt wurde, sind alle Skills bereits
> enthalten — dieser Schritt entfällt.

### Schritt 6: Abschluss

```
✓ marketing/CLAUDE.md
✓ marketing/_bundle.yml
✓ marketing/RAW/
✓ marketing/wiki/           ← das Brain (wächst mit /grill-me-workshop)
✓ marketing/.agents/        ← wird von /grill-me-workshop befüllt
✓ marketing/skills/         ← grill-me-workshop + update-context + 44 Skills

Nächster Schritt: /grill-me-workshop

Ich stelle euch ~10 gezielte Fragen zu eurem Startup.
Danach sind alle 44 Marketing-Skills sofort einsatzbereit
— kein Briefing mehr nötig.

Bereit? Dann: /grill-me-workshop
```

---

## Regeln

- Niemals bestehende Dateien überschreiben (prüfe vorher)
- Niemals `wiki/` oder `.agents/` mit Beispieldaten befüllen
- Immer zuerst prüfen ob der Ordner schon existiert
- Skills-Pfade relativ zum aktuellen Arbeitsverzeichnis auflösen
